import com.acme.test01.kobaAbzianidze.domain.CurrentAccount;
import com.acme.test01.kobaAbzianidze.domain.SavingsAccount;
import com.acme.test01.kobaAbzianidze.exceptions.AccountNotFoundException;
import com.acme.test01.kobaAbzianidze.exceptions.WithdrawalAmountTooLargeException;
import com.acme.test01.kobaAbzianidze.repository.SystemDB;
import com.acme.test01.kobaAbzianidze.service.AccountService;
import com.acme.test01.kobaAbzianidze.service.AccountServiceImpl;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class AccountServiceTest {

    private AccountService accountService;
    private SystemDB systemDB;

    @BeforeEach
    public void setUp() {
        /*
        db.put(1L, new SavingsAccount(1L, 1L, 2000));
        db.put(2L, new SavingsAccount(2L, 2L, 5000));
        db.put(3L, new CurrentAccount(3L, 3L, 1000, 10000));
        db.put(4L, new CurrentAccount(4L, 4L, -5000, 20000));
         */
        accountService = new AccountServiceImpl();
        systemDB = SystemDB.getInstance();
    }

    @Test
    public void testOpenSavingsAccount() {
        // Test opening a savings account with an insufficient initial deposit
        assertThrows(AccountNotFoundException.class, () -> {
            accountService.openSavingsAccount(10L, 500);
        });
    }

    @Test
    public void testOpenCurrentAccount() {
        // Test opening a current account
        assertThrows(IllegalArgumentException.class , () -> {
           accountService.openCurrentAccount(1L);
        });
    }

    @Test
    public void testWithdrawSavingsAccount() throws WithdrawalAmountTooLargeException {
        // Test withdrawing from a savings account with a valid balance
        accountService.withdraw(1L, 500);
        assertEquals(1500, ((SavingsAccount) systemDB.getAccounts().get(1L)).getBalance());

        // Test withdrawing from a savings account with an insufficient balance
        assertThrows(WithdrawalAmountTooLargeException.class, () -> {
            accountService.withdraw(1L, 2000);
        });
    }

    @Test
    public void testWithdrawCurrentAccount() throws AccountNotFoundException, WithdrawalAmountTooLargeException {
        // Test withdrawing from a current account with a positive balance
        final int differenceFor1 = ((CurrentAccount)this.systemDB.getAccounts().get(3L)).getBalance() - 500;
        accountService.withdraw(3L, 500);
        assertEquals(differenceFor1, ((CurrentAccount) systemDB.getAccounts().get(3L)).getBalance());

        final int differenceFor2 = ((CurrentAccount)this.systemDB.getAccounts().get(3L)).getBalance() - 5000;
        // Test withdrawing from a current account with a negative balance within overdraft limit
        accountService.withdraw(3L, 5000);
        assertEquals(differenceFor2, ((CurrentAccount) systemDB.getAccounts().get(3L)).getBalance());

        final int differenceFor3 = ((CurrentAccount)this.systemDB.getAccounts().get(3L)).getBalance() - 500;
        // Test withdrawing from a current account with a negative balance exceeding overdraft limit
        assertThrows(WithdrawalAmountTooLargeException.class, () -> {
            accountService.withdraw(3L, 15000);
        });
    }

    @Test
    public void testDeposit() throws AccountNotFoundException {
        // Test depositing into a savings account
        final int differenceFor1 = ((SavingsAccount)this.systemDB.getAccounts().get(1L)).getBalance() + 1000;
        accountService.deposit(1L, 1000);
        assertEquals(differenceFor1, ((SavingsAccount) systemDB.getAccounts().get(1L)).getBalance());

        final int differenceFor2 = ((CurrentAccount)this.systemDB.getAccounts().get(3L)).getBalance() + 5000;
        // Test depositing into a current account
        accountService.deposit(3L, 5000);
        assertEquals(differenceFor2, ((CurrentAccount) systemDB.getAccounts().get(3L)).getBalance());
    }

    @Test
    public void testWithdrawAccountNotFound() {
        // Test withdrawing from an account that does not exist
        assertThrows(AccountNotFoundException.class, () -> {
            accountService.withdraw(601L, 1000);
        });
    }

    @Test
    public void testDepositAccountNotFound() {
        // Test depositing into an account that does not exist
        assertThrows(AccountNotFoundException.class, () -> {
            accountService.deposit(701L, 1000);
        });
    }
}
