package com.acme.test01.kobaAbzianidze.domain;

import com.acme.test01.kobaAbzianidze.exceptions.WithdrawalAmountTooLargeException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CurrentAccount implements Account {
    private static final Logger log = LogManager.getLogger(CurrentAccount.class);
    private Long id;
    private Long customerNum;
    private Integer balance;
    private Integer overdraftLimit;

    public CurrentAccount(Long id, Long customerNum, Integer initialBalance, Integer overdraftLimit) {
        this.id = id;
        this.customerNum = customerNum;
        this.balance = initialBalance;
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void withdraw(Integer amount) throws WithdrawalAmountTooLargeException {
        Integer availableBalance = balance + overdraftLimit;
        if (amount > availableBalance) {
            log.debug("given amount:{} , And availableBalance: {} is less than amount" , amount , availableBalance);
            throw new WithdrawalAmountTooLargeException("Withdrawal amount exceeds available balance");
        }
        log.debug("balance before withdraw: {}" , this.balance);
        balance -= amount;
        log.debug("balance after withdraw: {}" , this.balance);
    }

    @Override
    public void deposit(Integer amount) {
        log.debug("balance before deposit: {}" , this.balance);
        balance += amount;
        log.debug("balance after deposit: {}" , this.balance);
    }

    public Integer getBalance(){
        return this.balance;
    }

}
