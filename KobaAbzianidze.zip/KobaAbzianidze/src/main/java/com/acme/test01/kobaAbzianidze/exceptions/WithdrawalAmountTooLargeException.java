package com.acme.test01.kobaAbzianidze.exceptions;

public class WithdrawalAmountTooLargeException extends Exception{
    public WithdrawalAmountTooLargeException() {
        super("WithdrawalAmountTooLargeException");
    }

    public WithdrawalAmountTooLargeException(String message) {
        super(message);
    }
}
