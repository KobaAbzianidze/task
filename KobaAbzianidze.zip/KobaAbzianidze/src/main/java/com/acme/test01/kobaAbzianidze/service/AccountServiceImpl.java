package com.acme.test01.kobaAbzianidze.service;

import com.acme.test01.kobaAbzianidze.domain.Account;
import com.acme.test01.kobaAbzianidze.domain.CurrentAccount;
import com.acme.test01.kobaAbzianidze.domain.SavingsAccount;
import com.acme.test01.kobaAbzianidze.exceptions.AccountNotFoundException;
import com.acme.test01.kobaAbzianidze.exceptions.WithdrawalAmountTooLargeException;
import com.acme.test01.kobaAbzianidze.repository.SystemDB;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AccountServiceImpl implements AccountService {

    private static final Logger log = LogManager.getLogger(AccountServiceImpl.class);

    private SystemDB systemDB = SystemDB.getInstance();

    @Override
    public void openSavingsAccount(Long accountId, Integer amountToDeposit) {
        log.info("openSavingsAccount has been called in AccountServiceImpl");
        final Account account = getAccount(accountId);
        if(!(account instanceof SavingsAccount)){
            log.debug("Account: {} , is not belong to SavingAccount type, due to given accountId:{} , And exception has been thrown" , account , accountId);
            throw new IllegalArgumentException("accountId does not belong to SavingAccount ID: " + accountId);
        }
        if (amountToDeposit < 1000) {
            log.debug("given deposit: {}  is lower than 1_000, And exception has been thrown" , account);
            throw new IllegalArgumentException("Initial deposit for a savings account must be at least 1000");
        }
        account.deposit(amountToDeposit);
    }

    private Account getAccount(Long accountId) {
        log.info("getAccount has been called in AccountServiceImpl");
        final Account account = systemDB.getAccounts()
                .entrySet()
                .stream().filter(entry -> entry.getKey().equals(accountId))
                .findFirst()
                .orElseThrow(AccountNotFoundException::new)
                .getValue();
        log.debug("Account fetched from Database(SystemDB): {} " , account);
        return account;
    }

    @Override
    public void openCurrentAccount(Long accountId) {
        final Account account = getAccount(accountId);
        if(!(account instanceof CurrentAccount)){
            log.debug("Account: {} , is not belong to SavingAccount type, due to given accountId:{} , And exception has been thrown" , account , accountId);
            throw new IllegalArgumentException("accountId does not belong to CurrentAccount ID: " + accountId);
        }
    }

    @Override
    public void withdraw(Long accountId, Integer amountToWithdraw)
            throws AccountNotFoundException, WithdrawalAmountTooLargeException {
        log.info("withdraw has been called in AccountServiceImpl");
        Account account = getAccount(accountId);
        account.withdraw(amountToWithdraw);
    }

    @Override
    public void deposit(Long accountId, Integer amountToDeposit) throws AccountNotFoundException {
        log.info("deposit has been called in AccountServiceImpl");
        Account account = getAccount(accountId);
        account.deposit(amountToDeposit);
    }
}
