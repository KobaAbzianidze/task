package com.acme.test01.kobaAbzianidze.domain;

import com.acme.test01.kobaAbzianidze.domain.Account;
import com.acme.test01.kobaAbzianidze.exceptions.WithdrawalAmountTooLargeException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SavingsAccount implements Account {

    private static final Logger log = LogManager.getLogger(SavingsAccount.class);
    private Long id;
    private Long customerNum;
    private Integer balance;

    public SavingsAccount(Long id, Long customerNum, Integer initialBalance) {
        this.id = id;
        this.customerNum = customerNum;
        this.balance = initialBalance;
    }

    @Override
    public void withdraw(Integer amount) throws WithdrawalAmountTooLargeException {
        log.info("withdraw has been called in SavingsAccount");
        int difference = balance - amount;
        if (difference < 1000) {
            log.debug("given amount:{} , And difference between balance and amount: {} is less than 1_000" , amount , difference);
            throw new WithdrawalAmountTooLargeException("Insufficient balance for withdrawal");
        }
        log.debug("balance before withdraw: {}" , this.balance);
        balance -= amount;
        log.debug("balance after withdraw: {}" , this.balance);
    }

    @Override
    public void deposit(Integer amount) {
        log.debug("balance before deposit: {}" , this.balance);
        balance += amount;
        log.debug("balance after deposit: {}" , this.balance);
    }


    public Integer getBalance(){
        return this.balance;
    }
}
