package com.acme.test01.kobaAbzianidze.exceptions;

public class AccountNotFoundException extends RuntimeException{
    public AccountNotFoundException() {
        super("AccountNotFoundException");
    }

    public AccountNotFoundException(String message) {
        super(message);
    }
}
