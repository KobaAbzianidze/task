package com.acme.test01.kobaAbzianidze.domain;

public class Customer {
    private final String customerNumber;

    public Customer(String customerNumber) {
        this.customerNumber = customerNumber;
    }
}
