package com.acme.test01.kobaAbzianidze.domain;

import com.acme.test01.kobaAbzianidze.exceptions.WithdrawalAmountTooLargeException;

public interface Account {
    void withdraw(Integer amount) throws WithdrawalAmountTooLargeException;
    void deposit(Integer amount);
}
