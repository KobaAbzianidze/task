package com.acme.test01.kobaAbzianidze.service;

import com.acme.test01.kobaAbzianidze.exceptions.AccountNotFoundException;
import com.acme.test01.kobaAbzianidze.exceptions.WithdrawalAmountTooLargeException;

public interface AccountService {
    public void openSavingsAccount(Long accountId, Integer amountToDeposit);
    public void openCurrentAccount(Long accountId);
    public void withdraw(Long accountId, Integer amountToWithdraw)
            throws AccountNotFoundException, WithdrawalAmountTooLargeException;
    public void deposit(Long accountId, Integer amountToDeposit)
            throws AccountNotFoundException;

}
