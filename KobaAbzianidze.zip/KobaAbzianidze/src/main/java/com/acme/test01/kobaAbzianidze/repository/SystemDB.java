package com.acme.test01.kobaAbzianidze.repository;

import com.acme.test01.kobaAbzianidze.domain.Account;
import com.acme.test01.kobaAbzianidze.domain.CurrentAccount;
import com.acme.test01.kobaAbzianidze.domain.SavingsAccount;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

public class SystemDB {

    private static final Logger log = LogManager.getLogger(SystemDB.class);
    private static SystemDB systemDB_instance = null;
    private final Map<Long, Account> db = new HashMap();

    private SystemDB() {
        db.put(1L, new SavingsAccount(1L, 1L, 2000));
        db.put(2L, new SavingsAccount(2L, 2L, 5000));
        db.put(3L, new CurrentAccount(3L, 3L, 1000, 10000));
        db.put(4L, new CurrentAccount(4L, 4L, -5000, 20000));
    }

    public static synchronized SystemDB getInstance(){
        if(systemDB_instance == null)
            systemDB_instance = new SystemDB();
        return systemDB_instance;
    }

    public Map<Long , Account> getAccounts(){
        return db;
    }

}
